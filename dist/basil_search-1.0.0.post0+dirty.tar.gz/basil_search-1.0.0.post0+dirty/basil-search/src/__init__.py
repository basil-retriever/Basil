__version__ = "1.0.0"
__author__ = "Niels Jacobs"
__description__ = "Website Content Scraper and Search Engine"